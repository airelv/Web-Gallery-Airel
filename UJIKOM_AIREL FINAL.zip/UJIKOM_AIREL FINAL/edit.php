<!-- edit.php -->
<?php
require_once 'Gallery.php';

$gallery = new Gallery();

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'edit') {
    // Ambil ID dari formulir
    $id = $_POST['id'];

    // Dapatkan informasi foto
    $image = $gallery->getImageInfo($id);

    if (!$image) {
        echo "Foto tidak ditemukan.";
        exit();
    }

    // Proses edit foto
    $editResult = $gallery->editImage($id, $_FILES['image'], $_POST['newCaption']);

    if ($editResult === true) {
        header("Location: index.php");
        exit();
    } else {
        $error = $editResult;
    }
} elseif ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['id'])) {
    // Ambil ID dari URL
    $id = $_GET['id'];

    // Dapatkan informasi foto
    $image = $gallery->getImageInfo($id);

    if (!$image) {
        echo "Foto tidak ditemukan.";
        exit();
    }
} else {
    echo "ID foto tidak valid.";
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Photo</title>
    <style>
        /* Tambahkan gaya CSS sesuai kebutuhan */
    </style>
</head>

<body>
    <h1>Edit Photo</h1>

    <div class="content">
        <img src="<?php echo $image['filename']; ?>" alt="<?php echo $image['caption']; ?>">
        <form action="edit.php" method="post" enctype="multipart/form-data">
            <input type="hidden" name="action" value="edit">
            <input type="hidden" name="id" value="<?php echo $image['id']; ?>">
            <label for="newImage">Edit Foto:</label>
            <input type="file" name="image" id="newImage" accept="image/*">
            <label for="newCaption">Edit Caption:</label>
            <input type="text" name="newCaption" id="newCaption" value="<?php echo $image['caption']; ?>" required>
            <button type="submit">Edit Foto dan Caption</button>
        </form>
    </div>

    <?php if (!empty($error)): ?>
        <p style="color: red;"><?php echo $error; ?></p>
    <?php endif; ?>
</body>

</html>