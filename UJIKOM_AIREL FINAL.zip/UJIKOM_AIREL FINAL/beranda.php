<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.3/font/bootstrap-icons.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@9/swiper-bundle.min.css" />
    <script src="https://cdn.jsdelivr.net/npm/swiper@9/swiper-bundle.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.3/jquery.min.js"></script>
    <link rel="stylesheet" href="css/gnb.css">
    <link rel="stylesheet" href="css/default.css">
    <title>Instagram - Clone coding</title>
    <style>
        @import url(css/default.css);
        @import url(css/gnb.css);

        .main {
            background-color: #fafafa;
            padding-top: 25px;

            align-items: flex-start;
        }

        .feed {
            background-color: white;
            width: 470px;
            margin-right: 30px;

            border-radius: 8px;
            border: 0.5px solid lightgray;

            font-size: 13px;
            padding-bottom: 20px;
            margin-bottom: 20px;
        }

        .account {
            width: 320px;
            margin-top: 10px;
            font-size: 14px;
        }

        .account-content {
            width: 100%;
        }

        .account-content>li {
            justify-content: space-between;

            margin-top: 20px;
            margin-bottom: 20px;
        }

        .account-content>li>p {
            margin-left: 20px;
            margin-right: auto;

            align-items: flex-start;
        }

        .account-content>li>a {
            color: skyblue;
            font-size: 13px;
        }

        .account-content>li>p>span:first-child {
            font-weight: bold;
            color: black;
        }

        .account-content>li>p>span:last-child {
            color: gray;
        }

        .img-wrap {
            border-radius: 50%;
            overflow: hidden;
            border: 0.5px solid #f2f2f2;
            display: flex;
        }

        li.suggestions>span {
            color: gray;
        }

        li.suggestions>a {
            color: black;
        }

        .about {
            margin-top: 30px;
            margin-bottom: 30px;
        }

        .about>a {
            color: lightgray;
            font-size: 11px;
            margin-right: 2px;
        }

        .name {
            color: lightgray;
            font-size: 11px;

            margin-right: auto;
        }

        .profile {
            justify-content: space-between;
            width: 100%;
            padding: 15px;
            box-sizing: border-box;
        }

        .profile>p {
            margin-left: 18px;
            margin-right: auto;
        }

        .profile>p>span:first-child {
            font-weight: bold;
            margin-bottom: 5px;
            margin-right: auto;
        }

        .imgs>div>img {
            width: 100%;
        }

        .feed-icons {
            width: 97%;
            margin-top: 5px;
            margin-bottom: 5px;
        }

        .feed-icons>img {
            margin-right: 10px;
            cursor: pointer;
        }

        .feed-icons>img:last-child {
            margin-left: auto;

        }

        .likes {
            margin-right: auto;
            margin-left: 20px;
            margin-top: 5px;
            margin-bottom: 5px;
            font-weight: bold;
        }

    </style>
    <script>
        let is_liked = true;
        function like() {
            if (is_liked == true) {
                $('#heart').attr('src', 'image/icons/12.png')
                is_liked = false;
            } else {
                $('#heart').attr('src', 'image/icons/5.png')
                is_liked = true;
            }
        }
        
    </script>
</head>

<body>
    <div class="gnb flex-row">
        <div class="gnb-content flex-row">
            <div class="logo flex-row">
                <img width="102" src="image/logo_instagram.png">
                <i class="bi bi-chevron-down"></i>
            </div>
            <div class="search-box flex-row">
                <input type="text" placeholder="Search">
            </div>
            <div class="icons flex-row">
                <img src="image/icons/1.png">
                <img src="image/icons/2.png">
                <a href="addphoto.html">
                    <img src="image/icons/3.png" alt="Add Photo">
                </a>
                
<img src="image/icons/4.png">
                <img src="image/icons/5.png">
                <img width="32" src="image/icons/6.png">
              <li><a href="logout.php" onclick="sign_out()">
                        <i class='bx bx-log-out'></i>
                        <span class="link-name">Logout</span>
                    </a></li>
            </div>
        </div>
    </div>
    
    <?php
class Gallery
{
    private $db;
    public function __construct()
    {
        $this->db = new mysqli("localhost", "root", "", "UKK2024_ARIELVALEN");
        if ($this->db->connect_error) {
            die("Connection failed: " . $this->db->connect_error);
        }
    }

    public function getFoto()
    {
        $foto = [];
        $query = "SELECT * FROM foto";
        $result = $this->db->query($query);
        while ($row = $result->fetch_assoc()) {
            $foto[] = $row;
        }
        return $foto;
    }

    public function uploadfoto($file, $DeskripsiFoto)
    {
        $targetDir = "foto/";
        $targetFile = $targetDir . basename($file['name']);
        $fotoFileType = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));

        // Check if the file is an actual foto
        $check = getimagesize($file['tmp_name']);
        if ($check === false) {
            return "File is not a foto.";
        }

        // Check if file already exists
        

        // Check file size
        if ($file['size'] > 5000000) { // 5 MB
            return "Sorry, your file is too large.";
        }

        // Allow certain file formats
        $allowedFormats = ['jpg', 'jpeg', 'png', 'gif'];
        if (!in_array($fotoFileType, $allowedFormats)) {
            return "Sorry, only JPG, JPEG, PNG, and GIF files are allowed.";
        }

        // Move the file to the target directory
        if (move_uploaded_file($file['tmp_name'], $targetFile)) {
            $this->saveToDatabase($targetFile, $DeskripsiFoto);
            return true;
        } else {
            return "Sorry, there was an error uploading your file.";
        }
    }

    private function saveToDatabase($JudulFoto, $DeskripsiFoto)
    {
        $query = "INSERT INTO foto (JudulFoto, DeskripsiFoto) VALUES ('$JudulFoto', '$DeskripsiFoto')";
        if (!$this->db->query($query)) {
            return "Error: " . $this->db->error;
        }
    }

    public function deletefoto($fotoID)
    {
        // Dapatkan informasi file yang akan dihapus
        $fotoInfo = $this->getFotoInfo($fotoID);
    
        if (!$fotoInfo) {
            return "Foto not found.";
        }
    
        // Pengecekan apakah file fisiknya ada sebelum mencoba menghapusnya
        if (file_exists($fotoInfo['FotoID'])) {
            // Hapus file dari direktori
            if (unlink($fotoInfo['FotoID'])) {
                // Hapus data dari database
                $query = "DELETE FROM foto WHERE JudulFoto = '$fotoID'";
                if (!$this->db->query($query)) {
                    return "Error: " . $this->db->error;
                }
                return true;
            } else {
                return "Failed to delete foto.";
            }
        } else {
            // Jika file fisik tidak ditemukan, hapus saja dari basis data
            $query = "DELETE FROM foto WHERE FotoID = '$fotoID'";
            if (!$this->db->query($query)) {
                return "Error: " . $this->db->error;
            }
            return true;
        }
    }

    public function editfoto($id, $file, $newDeskripsiFoto)
    {
        $fotoInfo = $this->getFotoInfo($id);

        if (!$fotoInfo) {
            return "Foto not found.";
        }

        // Jika tidak ada file yang diunggah, hanya edit DeskripsiFoto
        if (empty($file['name'])) {
            $query = "UPDATE foto SET DeskripsiFoto = '$newDeskripsiFoto' WHERE FotoID = '$foto'";
            if (!$this->db->query($query)) {
                return "Error: " . $this->db->error;
            }
            return true;
        }

        // Jika ada file yang diunggah, proses seperti biasa
        $targetDir = "foto/";
        $targetFile = $targetDir . basename($file['foto']);

        // Hapus file lama
        unlink($fotoInfo['FotoID']);

        // Pindahkan file baru
        if (move_uploaded_file($file['tmp_name'], $targetFile)) {
            // Update DeskripsiFoto di database
            $query = "UPDATE foto SET FotoID = '$targetFile', DeskripsiFoto = '$newDeskripsiFoto' WHERE FotoID = '$id'";
            if (!$this->db->query($query)) {
                return "Error: " . $this->db->error;
            }
            return true;
        } else {
            return "Failed to upload file.";
        }
    }

    public function hapusDeskripsiFoto($FotoID)
    {
        $fotoInfo = $this->getFotoInfo($FotoID);

        if (!$fotoInfo) {
            return "Foto not found.";
        }

        // Hapus DeskripsiFoto dari database
        $query = "UPDATE foto SET DeskripsiFoto = NULL WHERE FotoID = '$FotoID'";
        if (!$this->db->query($query)) {
            return "Error: " . $this->db->error;
        }

        return true;
    }

    public function getFotoInfo($FotoID)
    {
        $FotoID = $this->db->real_escape_string($FotoID);
        $query = "SELECT * FROM foto WHERE FotoID = '$FotoID'";
        $result = $this->db->query($query);

        return $result->fetch_assoc();
    }
    
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Web Gallery</title>
    <style>
        * {
            font-family: arial;
        }

        .gallery {
            display: flex;
            flex-direction: row;

            gap: 15px;
            
        }

        .gallery img {
            max-width: 200px;
            max-height: 150px;
            border-radius: 10px;
        }

        .content {
            display: flex;
            flex-direction: column;
            background-color: rgb(236, 236, 236);
            border-radius: 10px;
        }

        .caption {
            display: flex;
            align-items: center;
            justify-content: center;
        }
    </style>
</head>

<body>
    <h1>Web Gallery</h1>

    <div class="gallery">
        <?php foreach ($images as $image): ?>

        <div class="content">
           <img src="<?php echo $image['filename']; ?>" alt="<?php echo $image['caption']; ?>">
            <p class="caption">
               <?php echo $image['caption']; ?>
            </p>
            <a href="edit.php?id=<?php echo $image['id']; ?>">Edit Foto</a>
            <a href="index.php?action=delete&id=<?php echo $image['id']; ?>" onclick="return confirm('Apakah Anda yakin ingin menghapus foto ini?')">Hapus Foto</a> 
            <!-- Form for image actions -->
<form action="index.php" method="post">
    <input type="hidden" name="action" value="hapus_caption">
    <input type="hidden" name="image_id" value="<?php echo $image['id']; ?>">
    <button type="submit">Hapus Caption</button>
</form>
        </div>   
    
        <?php endforeach; ?>
    </div>

    <br><br>

    <!-- Form for image upload -->
    <form action="index.php" method="post" enctype="multipart/form-data">
        <label for="image">Choose Image:</label>
        <input type="file" name="image" id="image" accept="image/*" required> <br>

        <label for="caption">Caption:</label>
        <input type="text" name="caption" id="caption" required> <br>

        <button type="submit">Upload Image</button>
    </form>

    <?php if (isset($error)): ?>

    <p style="color: red;">
        <?php echo $error; ?>
    </p>
    <?php endif; ?>

</body>

</html>

            
            
        <div class="account flex-col">
            <div class="account-content">
                <li class="flex-row">
                    <div class="img-wrap">
                        <img width="56px" src="image/profile/toji.jpg">
                    </div>
                    
            </div>
            <div class="about">
                <a href="#">About</a>
                <a href="#">Help</a>
                <a href="#">Press</a>
                <a href="#">API</a>
                <a href="#">Jobs</a>
                <a href="#">Privacy</a>
                <a href="#">Terms</a>
                <a href="#">Location</a>
                <a href="#">language</a>
                <a href="#">English</a>
            </div>
              
              <ul class="logout-mode">

              
              
              
              
            </div>
        </div>
    </div>
    
</body>

</html>


