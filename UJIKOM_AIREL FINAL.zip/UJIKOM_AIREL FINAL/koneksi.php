<?php
$server    = "localhost";
$username  = "root";
$pass      = "";
$db        = "ukk2024_airel";
$koneksi   = mysqli_connect($server, $username, $pass, $db);

if($koneksi){
    echo "Terhubung";
}else{
    echo "Tidak tehubung";
}

?>